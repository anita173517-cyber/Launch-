package com.harindra.tvlauncher

import android.content.Context
import android.content.SharedPreferences

class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("ultratv_pro_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PINNED = "pinned_apps_csv"
        private const val KEY_HIDDEN = "hidden_apps_csv"
        private const val KEY_LOCKED = "locked_apps_csv"
        private const val KEY_RECENT = "recent_apps_csv"
        private const val KEY_FAV_CHANNELS = "fav_channels_csv"
        private const val KEY_THEME = "theme_index"
        private const val KEY_SHOW_HERO = "show_hero"
        private const val KEY_SHOW_RAM = "show_ram"
        private const val KEY_SHOW_QUICK = "show_quick_bar"
        private const val KEY_24H_CLOCK = "clock_24h"
        private const val KEY_GRID_COLS = "grid_cols"
        private const val KEY_BOOT_MODE = "boot_mode" // 0=Home, 1=App, 2=LastChannel
        private const val KEY_AUTO_LAUNCH_PKG = "auto_launch_pkg"
        private const val KEY_ULTRA_LITE = "ultra_lite_mode"
        private const val KEY_AUTO_RAM_GUARD = "auto_ram_guard"
        private const val KEY_M3U_URL = "m3u_url"
        private const val KEY_IPTV_PLAYER_PKG = "iptv_player_pkg"
        private const val KEY_LAST_CHANNEL_URL = "last_channel_url"
        private const val KEY_LAST_CHANNEL_NAME = "last_channel_name"
        private const val KEY_KIDS_PIN = "kids_pin"
        private const val KEY_SPEED_DIAL_PREFIX = "speed_dial_"
    }

    fun getPinnedPackages(): MutableList<String> = readCsvList(KEY_PINNED)
    fun savePinnedPackages(list: List<String>) = saveCsv(KEY_PINNED, list.distinct())

    fun getHiddenPackages(): MutableSet<String> = readCsvList(KEY_HIDDEN).toMutableSet()
    fun saveHiddenPackages(set: Set<String>) = saveCsv(KEY_HIDDEN, set.toList())

    fun getLockedPackages(): MutableSet<String> = readCsvList(KEY_LOCKED).toMutableSet()
    fun saveLockedPackages(set: Set<String>) = saveCsv(KEY_LOCKED, set.toList())

    fun getFavoriteChannelIds(): MutableSet<String> = readCsvList(KEY_FAV_CHANNELS).toMutableSet()
    fun saveFavoriteChannelIds(set: Set<String>) = saveCsv(KEY_FAV_CHANNELS, set.toList())

    fun getRecentPackages(): MutableList<String> = readCsvList(KEY_RECENT)
    fun recordRecentPackage(pkg: String) {
        val list = getRecentPackages()
        list.remove(pkg)
        list.add(0, pkg)
        saveCsv(KEY_RECENT, if (list.size > 12) list.subList(0, 12) else list)
    }

    // Remote Speed-Dial Keys 1..9 -> stores "app:<pkg>" or "ch:<url>"
    fun setSpeedDial(digit: Int, target: String) {
        prefs.edit().putString(KEY_SPEED_DIAL_PREFIX + digit, target).apply()
    }

    fun getSpeedDial(digit: Int): String =
        prefs.getString(KEY_SPEED_DIAL_PREFIX + digit, "") ?: ""

    fun findSpeedDialDigit(target: String): Int? {
        for (d in 1..9) {
            if (getSpeedDial(d) == target) return d
        }
        return null
    }

    private fun readCsvList(key: String): MutableList<String> {
        val raw = prefs.getString(key, "") ?: ""
        return if (raw.isBlank()) mutableListOf()
        else raw.split("||").filter { it.isNotBlank() }.toMutableList()
    }

    private fun saveCsv(key: String, list: List<String>) {
        prefs.edit().putString(key, list.joinToString("||")).apply()
    }

    var themeIndex: Int
        get() = prefs.getInt(KEY_THEME, 0)
        set(value) = prefs.edit().putInt(KEY_THEME, value).apply()

    var showHeroBanner: Boolean
        get() = prefs.getBoolean(KEY_SHOW_HERO, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_HERO, value).apply()

    var showRamMeter: Boolean
        get() = prefs.getBoolean(KEY_SHOW_RAM, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_RAM, value).apply()

    var showQuickBar: Boolean
        get() = prefs.getBoolean(KEY_SHOW_QUICK, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_QUICK, value).apply()

    var is24HourClock: Boolean
        get() = prefs.getBoolean(KEY_24H_CLOCK, false)
        set(value) = prefs.edit().putBoolean(KEY_24H_CLOCK, value).apply()

    var gridColumns: Int
        get() = prefs.getInt(KEY_GRID_COLS, 6)
        set(value) = prefs.edit().putInt(KEY_GRID_COLS, value).apply()

    var bootMode: Int
        get() = prefs.getInt(KEY_BOOT_MODE, 0)
        set(value) = prefs.edit().putInt(KEY_BOOT_MODE, value).apply()

    var autoLaunchPackage: String
        get() = prefs.getString(KEY_AUTO_LAUNCH_PKG, "") ?: ""
        set(value) = prefs.edit().putString(KEY_AUTO_LAUNCH_PKG, value).apply()

    var isUltraLiteMode: Boolean
        get() = prefs.getBoolean(KEY_ULTRA_LITE, false)
        set(value) = prefs.edit().putBoolean(KEY_ULTRA_LITE, value).apply()

    var isAutoRamGuard: Boolean
        get() = prefs.getBoolean(KEY_AUTO_RAM_GUARD, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_RAM_GUARD, value).apply()

    var m3uUrl: String
        get() = prefs.getString(KEY_M3U_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_M3U_URL, value).apply()

    var preferredIptvPlayer: String
        get() = prefs.getString(KEY_IPTV_PLAYER_PKG, "") ?: ""
        set(value) = prefs.edit().putString(KEY_IPTV_PLAYER_PKG, value).apply()

    var lastChannelUrl: String
        get() = prefs.getString(KEY_LAST_CHANNEL_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LAST_CHANNEL_URL, value).apply()

    var lastChannelName: String
        get() = prefs.getString(KEY_LAST_CHANNEL_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LAST_CHANNEL_NAME, value).apply()

    var kidsPin: String
        get() = prefs.getString(KEY_KIDS_PIN, "1234") ?: "1234"
        set(value) = prefs.edit().putString(KEY_KIDS_PIN, value).apply()
}
