package com.harindra.tvlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_LOCKED_BOOT_COMPLETED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == "com.htc.intent.action.QUICKBOOT_POWERON"
        ) {
            val prefs = PrefsManager(context)

            // Boot Mode 2: Auto-Play Last Watched Live TV Channel (DTH Mode!)
            if (prefs.bootMode == 2 && prefs.lastChannelUrl.isNotBlank()) {
                val streamIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(Uri.parse(prefs.lastChannelUrl), "video/*")
                    putExtra("title", prefs.lastChannelName)
                    if (prefs.preferredIptvPlayer.isNotBlank()) {
                        setPackage(prefs.preferredIptvPlayer)
                    }
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(streamIntent)
                    return
                } catch (_: Throwable) { }
            }

            // Boot Mode 1: Auto-Launch Favorite App (e.g., RAM PLAYER / IPTV)
            if (prefs.bootMode == 1 && prefs.autoLaunchPackage.isNotBlank()) {
                val pkg = prefs.autoLaunchPackage
                val launch = context.packageManager.getLeanbackLaunchIntentForPackage(pkg)
                    ?: context.packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(launch)
                        return
                    } catch (_: Throwable) { }
                }
            }

            // Boot Mode 0 (Default): Open UltraTV Pro Home instantly (< 1 sec)
            val homeIntent = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            try {
                context.startActivity(homeIntent)
            } catch (_: Throwable) { }
        }
    }
}
