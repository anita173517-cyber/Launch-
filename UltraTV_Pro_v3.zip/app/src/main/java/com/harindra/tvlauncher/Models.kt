package com.harindra.tvlauncher

data class AppItem(
    val packageName: String,
    val label: String,
    val isTvApp: Boolean,
    val isLiveTvCandidate: Boolean
)

data class LiveChannel(
    val id: String,
    val name: String,
    val group: String,
    val logoUrl: String,
    val streamUrl: String,
    val userAgent: String = "",
    val referrer: String = ""
)
