package com.harindra.tvlauncher

import android.app.Activity
import android.app.ActivityManager
import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PorterDuff
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQ_VOICE_SEARCH = 2001
    }

    private lateinit var prefs: PrefsManager

    // Top bar
    private lateinit var rootContainer: LinearLayout
    private lateinit var btnSearch: LinearLayout
    private lateinit var ivSearch: ImageView
    private lateinit var tvSearchLabel: TextView
    private lateinit var btnVoiceSearch: LinearLayout
    private lateinit var ivMic: ImageView
    private lateinit var tabForYou: TextView
    private lateinit var tabLive: TextView
    private lateinit var tabApps: TextView
    private lateinit var tabLibrary: TextView
    private lateinit var btnRamBoost: LinearLayout
    private lateinit var tvRamStatus: TextView
    private lateinit var btnNetwork: LinearLayout
    private lateinit var ivWifi: ImageView
    private lateinit var btnSettings: LinearLayout
    private lateinit var ivSettings: ImageView
    private lateinit var btnClock: LinearLayout
    private lateinit var tvClock: TextView
    private lateinit var tvDate: TextView

    // Search
    private lateinit var searchBarContainer: LinearLayout
    private lateinit var etSearch: EditText
    private lateinit var btnCloseSearch: TextView
    private lateinit var viewSearchResults: LinearLayout
    private lateinit var tvSearchChannelCount: TextView
    private lateinit var rvSearchChannels: RecyclerView
    private lateinit var tvSearchResultCount: TextView
    private lateinit var rvSearchResults: RecyclerView

    // Tab views
    private lateinit var viewForYou: LinearLayout
    private lateinit var viewLive: LinearLayout
    private lateinit var viewApps: LinearLayout
    private lateinit var viewLibrary: LinearLayout

    // Hero & Quick bar
    private lateinit var heroCard: LinearLayout
    private lateinit var tvHeroBadge: TextView
    private lateinit var tvHeroTitle: TextView
    private lateinit var tvHeroSubtitle: TextView
    private lateinit var tvHeroCta: TextView
    private lateinit var tvHeroStorage: TextView
    private lateinit var ivHeroIcon: ImageView
    private lateinit var quickActionsBar: View

    // Home Live Channels rail
    private lateinit var homeLiveSection: LinearLayout
    private lateinit var tvHomeLiveHeader: TextView
    private lateinit var btnHomeSeeAllLive: TextView
    private lateinit var rvHomeLiveChannels: RecyclerView

    // Live Tab views
    private lateinit var tvLiveTabTitle: TextView
    private lateinit var btnLiveAddM3u: TextView
    private lateinit var btnLiveRefreshM3u: TextView
    private lateinit var btnLiveChoosePlayer: TextView
    private lateinit var liveCategoryBar: LinearLayout
    private lateinit var tvLiveChannelsSubtitle: TextView
    private lateinit var rvLiveChannelsGrid: RecyclerView
    private lateinit var rvLiveApps: RecyclerView

    // Apps & Library views
    private lateinit var rvPinnedApps: RecyclerView
    private lateinit var rvRecentApps: RecyclerView
    private lateinit var tvRecentHeader: TextView
    private lateinit var rvAllRow: RecyclerView
    private lateinit var rvAllGrid: RecyclerView
    private lateinit var tvAppsTitle: TextView
    private lateinit var btnFilterAll: TextView
    private lateinit var btnFilterTv: TextView
    private lateinit var btnFilterSideload: TextView
    private lateinit var tvDeviceHealth: TextView
    private lateinit var tvFavChannelsHeader: TextView
    private lateinit var rvLibraryFavChannels: RecyclerView
    private lateinit var rvLibraryFavorites: RecyclerView

    // Adapters
    private lateinit var pinnedAdapter: AppAdapter
    private lateinit var recentAdapter: AppAdapter
    private lateinit var allRowAdapter: AppAdapter
    private lateinit var liveAppsAdapter: AppAdapter
    private lateinit var allGridAdapter: AppAdapter
    private lateinit var libraryFavAdapter: AppAdapter
    private lateinit var searchAppsAdapter: AppAdapter

    private lateinit var homeChannelsAdapter: ChannelAdapter
    private lateinit var liveChannelsAdapter: ChannelAdapter
    private lateinit var libraryFavChannelsAdapter: ChannelAdapter
    private lateinit var searchChannelsAdapter: ChannelAdapter

    // Data
    private var allInstalledApps: List<AppItem> = emptyList()
    private var allLiveChannels: List<LiveChannel> = emptyList()
    private var currentLiveGroup: String = "All"
    private var currentTab = 0
    private var currentAppFilter = 0
    private var featuredHeroApp: AppItem? = null
    private var heroSlideIndex = 0

    private val bgExecutor = Executors.newFixedThreadPool(2)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val themes = listOf(
        "Google TV Obsidian" to R.drawable.bg_theme_obsidian,
        "Midnight Blue" to R.drawable.bg_theme_midnight,
        "AMOLED Pure Black (Best for 512MB)" to R.drawable.bg_theme_amoled,
        "Emerald Night" to R.drawable.bg_theme_emerald,
        "Royal Purple" to R.drawable.bg_theme_royal,
        "Cinema Sunset" to R.drawable.bg_theme_sunset,
        "Deep Crimson" to R.drawable.bg_theme_crimson,
        "Carbon Slate" to R.drawable.bg_theme_slate
    )

    private val liveTvKeywords = listOf(
        "iptv", "ramplayer", "harindra", "tivimate", "ott", "live", "tv",
        "jio", "hotstar", "sonyliv", "zee5", "youtube", "vlc", "kodi",
        "mxplayer", "smarttube", "stremio", "netflix", "prime", "airtel",
        "tata", "sunnxt", "fancode", "mpv", "nova"
    )

    private val clockAndStatsRunnable = object : Runnable {
        override fun run() {
            updateClockAndStatus()
            mainHandler.postDelayed(this, 10_000L)
        }
    }

    private val heroRotateRunnable = object : Runnable {
        override fun run() {
            if (!prefs.isUltraLiteMode && prefs.showHeroBanner && currentTab == 0) {
                heroSlideIndex = (heroSlideIndex + 1) % 3
                updateHeroBanner()
            }
            mainHandler.postDelayed(this, 12_000L)
        }
    }

    private val packageChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadAppsAsync()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = PrefsManager(this)

        bindViews()
        setupAdapters()
        setupListeners()
        applyUserPreferences()
        updateClockAndStatus()
        selectTab(0)

        // Load installed apps & cached M3U channels immediately in parallel (< 300ms)
        loadAppsAsync()
        loadCachedChannelsAsync()

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(packageChangeReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(packageChangeReceiver, filter)
        }
    }

    override fun onResume() {
        super.onResume()
        updateClockAndStatus()
        // Auto 512MB RAM Guard when returning from heavy video/IPTV apps
        if (prefs.isAutoRamGuard && getRamInfo().first < 85L) {
            IconCache.trimMemory()
        }
        mainHandler.post(clockAndStatsRunnable)
        mainHandler.postDelayed(heroRotateRunnable, 12_000L)
        refreshUiLists()
        refreshChannelLists()
    }

    override fun onPause() {
        super.onPause()
        mainHandler.removeCallbacks(clockAndStatsRunnable)
        mainHandler.removeCallbacks(heroRotateRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(packageChangeReceiver)
        } catch (_: Throwable) { }
        bgExecutor.shutdownNow()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_MODERATE) {
            IconCache.trimMemory()
        }
    }

    private fun bindViews() {
        rootContainer = findViewById(R.id.rootContainer)
        btnSearch = findViewById(R.id.btnSearch)
        ivSearch = findViewById(R.id.ivSearch)
        tvSearchLabel = findViewById(R.id.tvSearchLabel)
        btnVoiceSearch = findViewById(R.id.btnVoiceSearch)
        ivMic = findViewById(R.id.ivMic)
        tabForYou = findViewById(R.id.tabForYou)
        tabLive = findViewById(R.id.tabLive)
        tabApps = findViewById(R.id.tabApps)
        tabLibrary = findViewById(R.id.tabLibrary)
        btnRamBoost = findViewById(R.id.btnRamBoost)
        tvRamStatus = findViewById(R.id.tvRamStatus)
        btnNetwork = findViewById(R.id.btnNetwork)
        ivWifi = findViewById(R.id.ivWifi)
        btnSettings = findViewById(R.id.btnSettings)
        ivSettings = findViewById(R.id.ivSettings)
        btnClock = findViewById(R.id.btnClock)
        tvClock = findViewById(R.id.tvClock)
        tvDate = findViewById(R.id.tvDate)

        searchBarContainer = findViewById(R.id.searchBarContainer)
        etSearch = findViewById(R.id.etSearch)
        btnCloseSearch = findViewById(R.id.btnCloseSearch)
        viewSearchResults = findViewById(R.id.viewSearchResults)
        tvSearchChannelCount = findViewById(R.id.tvSearchChannelCount)
        rvSearchChannels = findViewById(R.id.rvSearchChannels)
        tvSearchResultCount = findViewById(R.id.tvSearchResultCount)
        rvSearchResults = findViewById(R.id.rvSearchResults)

        viewForYou = findViewById(R.id.viewForYou)
        viewLive = findViewById(R.id.viewLive)
        viewApps = findViewById(R.id.viewApps)
        viewLibrary = findViewById(R.id.viewLibrary)

        heroCard = findViewById(R.id.heroCard)
        tvHeroBadge = findViewById(R.id.tvHeroBadge)
        tvHeroTitle = findViewById(R.id.tvHeroTitle)
        tvHeroSubtitle = findViewById(R.id.tvHeroSubtitle)
        tvHeroCta = findViewById(R.id.tvHeroCta)
        tvHeroStorage = findViewById(R.id.tvHeroStorage)
        ivHeroIcon = findViewById(R.id.ivHeroIcon)
        quickActionsBar = findViewById(R.id.quickActionsBar)

        homeLiveSection = findViewById(R.id.homeLiveSection)
        tvHomeLiveHeader = findViewById(R.id.tvHomeLiveHeader)
        btnHomeSeeAllLive = findViewById(R.id.btnHomeSeeAllLive)
        rvHomeLiveChannels = findViewById(R.id.rvHomeLiveChannels)

        tvLiveTabTitle = findViewById(R.id.tvLiveTabTitle)
        btnLiveAddM3u = findViewById(R.id.btnLiveAddM3u)
        btnLiveRefreshM3u = findViewById(R.id.btnLiveRefreshM3u)
        btnLiveChoosePlayer = findViewById(R.id.btnLiveChoosePlayer)
        liveCategoryBar = findViewById(R.id.liveCategoryBar)
        tvLiveChannelsSubtitle = findViewById(R.id.tvLiveChannelsSubtitle)
        rvLiveChannelsGrid = findViewById(R.id.rvLiveChannelsGrid)
        rvLiveApps = findViewById(R.id.rvLiveApps)

        rvPinnedApps = findViewById(R.id.rvPinnedApps)
        rvRecentApps = findViewById(R.id.rvRecentApps)
        tvRecentHeader = findViewById(R.id.tvRecentHeader)
        rvAllRow = findViewById(R.id.rvAllRow)
        rvAllGrid = findViewById(R.id.rvAllGrid)
        tvAppsTitle = findViewById(R.id.tvAppsTitle)
        btnFilterAll = findViewById(R.id.btnFilterAll)
        btnFilterTv = findViewById(R.id.btnFilterTv)
        btnFilterSideload = findViewById(R.id.btnFilterSideload)
        tvDeviceHealth = findViewById(R.id.tvDeviceHealth)
        tvFavChannelsHeader = findViewById(R.id.tvFavChannelsHeader)
        rvLibraryFavChannels = findViewById(R.id.rvLibraryFavChannels)
        rvLibraryFavorites = findViewById(R.id.rvLibraryFavorites)
    }

    private fun setupAdapters() {
        val appClick: (AppItem) -> Unit = { launchAppWithLockCheck(it) }
        val appLongClick: (AppItem) -> Unit = { showAppOptionsDialog(it) }
        val chClick: (LiveChannel) -> Unit = { playLiveChannel(it, null) }
        val chLongClick: (LiveChannel) -> Unit = { showChannelOptionsDialog(it) }

        pinnedAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)
        recentAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)
        allRowAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)
        liveAppsAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)
        allGridAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)
        libraryFavAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)
        searchAppsAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)

        homeChannelsAdapter = ChannelAdapter(prefs, chClick, chLongClick)
        liveChannelsAdapter = ChannelAdapter(prefs, chClick, chLongClick)
        libraryFavChannelsAdapter = ChannelAdapter(prefs, chClick, chLongClick)
        searchChannelsAdapter = ChannelAdapter(prefs, chClick, chLongClick)

        rvHomeLiveChannels.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvHomeLiveChannels.adapter = homeChannelsAdapter
        rvHomeLiveChannels.setHasFixedSize(true)

        rvPinnedApps.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvPinnedApps.adapter = pinnedAdapter
        rvPinnedApps.setHasFixedSize(true)

        rvRecentApps.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvRecentApps.adapter = recentAdapter
        rvRecentApps.setHasFixedSize(true)

        rvAllRow.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvAllRow.adapter = allRowAdapter
        rvAllRow.setHasFixedSize(true)

        val appCols = prefs.gridColumns.coerceIn(4, 7)
        val chCols = (appCols - 1).coerceIn(3, 5)

        rvLiveChannelsGrid.layoutManager = GridLayoutManager(this, chCols)
        rvLiveChannelsGrid.adapter = liveChannelsAdapter

        rvLiveApps.layoutManager = GridLayoutManager(this, appCols)
        rvLiveApps.adapter = liveAppsAdapter

        rvAllGrid.layoutManager = GridLayoutManager(this, appCols)
        rvAllGrid.adapter = allGridAdapter

        rvLibraryFavChannels.layoutManager = GridLayoutManager(this, chCols)
        rvLibraryFavChannels.adapter = libraryFavChannelsAdapter

        rvLibraryFavorites.layoutManager = GridLayoutManager(this, appCols)
        rvLibraryFavorites.adapter = libraryFavAdapter

        rvSearchChannels.layoutManager = GridLayoutManager(this, chCols)
        rvSearchChannels.adapter = searchChannelsAdapter

        rvSearchResults.layoutManager = GridLayoutManager(this, appCols)
        rvSearchResults.adapter = searchAppsAdapter
    }

    private fun setupListeners() {
        val darkText = Color.parseColor("#111318")
        val lightText = Color.parseColor("#F5F7FA")
        val subText = Color.parseColor("#9AA5B8")

        val tabViews = listOf(tabForYou, tabLive, tabApps, tabLibrary)
        tabViews.forEachIndexed { index, tv ->
            tv.setOnClickListener { selectTab(index) }
            tv.setOnFocusChangeListener { v, hasFocus ->
                (v as TextView).setTextColor(if (hasFocus) darkText else lightText)
            }
        }

        btnSearch.setOnFocusChangeListener { _, hasFocus ->
            tvSearchLabel.setTextColor(if (hasFocus) darkText else lightText)
            ivSearch.setColorFilter(if (hasFocus) darkText else lightText, PorterDuff.Mode.SRC_IN)
        }
        btnSearch.setOnClickListener { toggleSearch(true) }

        btnVoiceSearch.setOnFocusChangeListener { _, hasFocus ->
            ivMic.setColorFilter(if (hasFocus) darkText else lightText, PorterDuff.Mode.SRC_IN)
        }
        btnVoiceSearch.setOnClickListener { startVoiceSearch() }

        btnCloseSearch.setOnFocusChangeListener { _, hasFocus ->
            btnCloseSearch.setTextColor(if (hasFocus) darkText else lightText)
        }
        btnCloseSearch.setOnClickListener { toggleSearch(false) }

        btnRamBoost.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) tvRamStatus.setTextColor(darkText) else updateClockAndStatus()
        }
        btnRamBoost.setOnClickListener { boostRamNow() }

        btnNetwork.setOnFocusChangeListener { _, hasFocus ->
            ivWifi.setColorFilter(if (hasFocus) darkText else lightText, PorterDuff.Mode.SRC_IN)
        }
        btnNetwork.setOnClickListener { openSystemAction(Settings.ACTION_WIFI_SETTINGS) }

        btnSettings.setOnFocusChangeListener { _, hasFocus ->
            ivSettings.setColorFilter(if (hasFocus) darkText else lightText, PorterDuff.Mode.SRC_IN)
        }
        btnSettings.setOnClickListener { showLauncherSettingsDialog() }

        btnClock.setOnFocusChangeListener { _, hasFocus ->
            tvClock.setTextColor(if (hasFocus) darkText else lightText)
            tvDate.setTextColor(if (hasFocus) darkText else subText)
        }
        btnClock.setOnClickListener {
            startActivity(Intent(this, AmbientActivity::class.java))
        }

        heroCard.setOnClickListener {
            when (heroSlideIndex) {
                0 -> {
                    val lastUrl = prefs.lastChannelUrl
                    val lastCh = allLiveChannels.firstOrNull { it.streamUrl == lastUrl }
                    if (lastCh != null) {
                        playLiveChannel(lastCh, null)
                    } else {
                        val target = featuredHeroApp ?: allInstalledApps.firstOrNull { it.isLiveTvCandidate }
                        if (target != null) launchAppWithLockCheck(target) else selectTab(1)
                    }
                }
                1 -> boostRamNow()
                else -> showLauncherSettingsDialog()
            }
        }

        val pillButtons = listOf<TextView>(
            findViewById(R.id.qaLiveTv),
            findViewById(R.id.qaAddM3u),
            findViewById(R.id.qaBoostRam),
            findViewById(R.id.qaDefaultHome),
            findViewById(R.id.qaAmbient),
            findViewById(R.id.qaAndroidSettings),
            btnHomeSeeAllLive,
            btnLiveAddM3u,
            btnLiveRefreshM3u,
            btnLiveChoosePlayer
        )
        pillButtons.forEach { btn ->
            btn.setOnFocusChangeListener { v, hasFocus ->
                (v as TextView).setTextColor(if (hasFocus) darkText else lightText)
            }
        }

        findViewById<View>(R.id.qaLiveTv).setOnClickListener { openPrimaryIptvApp() }
        findViewById<View>(R.id.qaAddM3u).setOnClickListener { showM3uSetupDialog() }
        findViewById<View>(R.id.qaBoostRam).setOnClickListener { boostRamNow() }
        findViewById<View>(R.id.qaDefaultHome).setOnClickListener { promptSetDefaultLauncher() }
        findViewById<View>(R.id.qaAmbient).setOnClickListener {
            startActivity(Intent(this, AmbientActivity::class.java))
        }
        findViewById<View>(R.id.qaAndroidSettings).setOnClickListener {
            openSystemAction(Settings.ACTION_SETTINGS)
        }

        btnHomeSeeAllLive.setOnClickListener { selectTab(1) }
        btnLiveAddM3u.setOnClickListener { showM3uSetupDialog() }
        btnLiveRefreshM3u.setOnClickListener { reloadM3uFromSavedUrl() }
        btnLiveChoosePlayer.setOnClickListener { showPreferredPlayerDialog() }

        val filters = listOf(btnFilterAll, btnFilterTv, btnFilterSideload)
        filters.forEachIndexed { idx, btn ->
            btn.setOnClickListener {
                currentAppFilter = idx
                updateFilterSelection()
                refreshAppsGrid()
            }
            btn.setOnFocusChangeListener { v, hasFocus ->
                (v as TextView).setTextColor(if (hasFocus) darkText else lightText)
            }
        }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                performSearch(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun openPrimaryIptvApp() {
        val prefPkg = prefs.preferredIptvPlayer
        val target = allInstalledApps.firstOrNull { it.packageName == prefPkg }
            ?: allInstalledApps.firstOrNull { it.packageName == "com.harindra.iptvpro" }
            ?: allInstalledApps.firstOrNull { it.packageName.contains("iptv", true) }
        if (target != null) {
            launchAppWithLockCheck(target)
        } else {
            selectTab(1)
        }
    }

    // ==================== M3U LIVE TV ENGINE ====================
    private fun loadCachedChannelsAsync() {
        bgExecutor.execute {
            val cached = M3uRepository.loadCachedChannels(this)
            mainHandler.post {
                allLiveChannels = cached
                rebuildLiveCategoryBar()
                refreshChannelLists()
                updateHeroBanner()
            }
        }
    }

    private fun reloadM3uFromSavedUrl() {
        val url = prefs.m3uUrl.trim()
        if (url.isBlank()) {
            showM3uSetupDialog()
            return
        }
        Toast.makeText(this, "Updating Live TV channels...", Toast.LENGTH_SHORT).show()
        bgExecutor.execute {
            val res = M3uRepository.fetchAndCacheFromUrl(this, url)
            mainHandler.post {
                res.onSuccess { list ->
                    allLiveChannels = list
                    currentLiveGroup = "All"
                    rebuildLiveCategoryBar()
                    refreshChannelLists()
                    updateHeroBanner()
                    Toast.makeText(this, "Loaded ${list.size} Live TV channels!", Toast.LENGTH_LONG).show()
                }.onFailure { err ->
                    Toast.makeText(this, "Failed to load M3U: ${err.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showM3uSetupDialog() {
        val input = EditText(this).apply {
            hint = "https://example.com/playlist.m3u  OR paste #EXTM3U text"
            setText(prefs.m3uUrl)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#9AA5B8"))
            setPadding(32, 24, 32, 24)
            maxLines = 4
        }

        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Add IPTV / Live TV M3U Playlist")
            .setMessage("Enter your M3U / M3U8 playlist link (or paste raw #EXTM3U text). All channels will appear on Home & Live TV tab!")
            .setView(input)
            .setPositiveButton("Load Channels") { _, _ ->
                val raw = input.text?.toString()?.trim().orEmpty()
                if (raw.isBlank()) {
                    Toast.makeText(this, "Please enter an M3U URL or playlist text", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (raw.startsWith("http://", true) || raw.startsWith("https://", true)) {
                    prefs.m3uUrl = raw
                    reloadM3uFromSavedUrl()
                } else {
                    bgExecutor.execute {
                        val parsed = M3uRepository.saveAndParseRaw(this, raw)
                        mainHandler.post {
                            allLiveChannels = parsed
                            currentLiveGroup = "All"
                            rebuildLiveCategoryBar()
                            refreshChannelLists()
                            updateHeroBanner()
                            Toast.makeText(this, "Saved ${parsed.size} channels!", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            .setNeutralButton("Clear Playlist") { _, _ ->
                prefs.m3uUrl = ""
                M3uRepository.saveAndParseRaw(this, "")
                allLiveChannels = emptyList()
                rebuildLiveCategoryBar()
                refreshChannelLists()
                Toast.makeText(this, "Cleared M3U playlist", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun rebuildLiveCategoryBar() {
        liveCategoryBar.removeAllViews()
        if (allLiveChannels.isEmpty()) return

        val groups = mutableListOf("All", "★ Favorites")
        val uniqueGroups = allLiveChannels.map { it.group }.distinct().take(25)
        groups.addAll(uniqueGroups)

        val darkText = Color.parseColor("#111318")
        val lightText = Color.parseColor("#F5F7FA")

        for (grp in groups) {
            val pill = TextView(this).apply {
                text = grp
                textSize = 12f
                setTextColor(lightText)
                setBackgroundResource(R.drawable.bg_tab_pill)
                isFocusable = true
                isClickable = true
                gravity = Gravity.CENTER
                setPadding(24, 10, 24, 10)
                isSelected = (grp == currentLiveGroup)
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = 10
                layoutParams = lp

                setOnFocusChangeListener { v, hasFocus ->
                    (v as TextView).setTextColor(if (hasFocus) darkText else lightText)
                }
                setOnClickListener {
                    currentLiveGroup = grp
                    rebuildLiveCategoryBar()
                    refreshChannelLists()
                }
            }
            liveCategoryBar.addView(pill)
        }
    }

    private fun refreshChannelLists() {
        val favUrls = prefs.getFavoriteChannelIds()
        val favChannels = allLiveChannels.filter { it.streamUrl in favUrls }

        // Home screen Live TV rail
        if (allLiveChannels.isEmpty()) {
            homeLiveSection.visibility = View.GONE
        } else {
            homeLiveSection.visibility = View.VISIBLE
            val homePreview = (favChannels + allLiveChannels).distinctBy { it.streamUrl }.take(24)
            tvHomeLiveHeader.text = "🔴 Live TV Channels (${allLiveChannels.size})"
            homeChannelsAdapter.submitList(homePreview)
        }

        // Live Tab filtered grid
        val filtered = when (currentLiveGroup) {
            "All" -> allLiveChannels
            "★ Favorites" -> favChannels
            else -> allLiveChannels.filter { it.group == currentLiveGroup }
        }
        tvLiveTabTitle.text = if (allLiveChannels.isEmpty()) {
            "Live TV & IPTV Hub"
        } else {
            "Live TV • ${filtered.size} Channels"
        }
        tvLiveChannelsSubtitle.text = if (allLiveChannels.isEmpty()) {
            "Tip: Click '+ Add / Edit M3U' to show all your Live TV channels directly here & on Home!"
        } else {
            "Press OK to play in your IPTV Player • Hold OK for Favorites, Speed-Dial 1-9 & Player Picker"
        }
        liveChannelsAdapter.submitList(filtered)

        // Library favorite channels
        if (favChannels.isEmpty()) {
            tvFavChannelsHeader.visibility = View.GONE
            rvLibraryFavChannels.visibility = View.GONE
        } else {
            tvFavChannelsHeader.visibility = View.VISIBLE
            rvLibraryFavChannels.visibility = View.VISIBLE
            libraryFavChannelsAdapter.submitList(favChannels)
        }
    }

    private fun playLiveChannel(ch: LiveChannel, overridePlayerPkg: String?) {
        prefs.lastChannelUrl = ch.streamUrl
        prefs.lastChannelName = ch.name
        updateHeroBanner()

        val targetPkg = overridePlayerPkg ?: prefs.preferredIptvPlayer.ifBlank {
            // Auto-prefer user's own IPTV app if installed
            allInstalledApps.firstOrNull { it.packageName == "com.harindra.iptvpro" }?.packageName ?: ""
        }

        val streamIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(ch.streamUrl), "video/*")
            putExtra("title", ch.name)
            putExtra("name", ch.name)
            putExtra("url", ch.streamUrl)
            if (ch.userAgent.isNotBlank()) {
                putExtra("user_agent", ch.userAgent)
                putExtra("headers", arrayOf("User-Agent", ch.userAgent))
            }
            if (ch.referrer.isNotBlank()) {
                putExtra("referer", ch.referrer)
            }
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        if (targetPkg.isNotBlank()) {
            streamIntent.setPackage(targetPkg)
            try {
                startActivity(streamIntent)
                return
            } catch (_: Throwable) {
                streamIntent.setPackage(null)
            }
        }

        try {
            startActivity(Intent.createChooser(streamIntent, "Play ${ch.name} with"))
        } catch (_: Throwable) {
            Toast.makeText(this, "No video/IPTV player found for this stream", Toast.LENGTH_LONG).show()
        }
    }

    private fun showChannelOptionsDialog(ch: LiveChannel) {
        val favs = prefs.getFavoriteChannelIds()
        val isFav = ch.streamUrl in favs
        val options = arrayOf(
            "▶ Play ${ch.name}",
            "🎬 Choose Video/IPTV Player",
            if (isFav) "☆ Remove from Favorites" else "★ Add to Favorite Channels",
            "🔢 Assign Remote Speed-Dial Key (1-9)",
            "🚀 Set as Boot Auto-Play Channel (DTH Mode)"
        )

        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle(ch.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> playLiveChannel(ch, null)
                    1 -> showPlayerPickerForChannel(ch)
                    2 -> {
                        if (isFav) favs.remove(ch.streamUrl) else favs.add(ch.streamUrl)
                        prefs.saveFavoriteChannelIds(favs)
                        refreshChannelLists()
                        Toast.makeText(this, if (isFav) "Removed from Favorites" else "Added to Favorites ★", Toast.LENGTH_SHORT).show()
                    }
                    3 -> showSpeedDialAssignDialog("ch:${ch.streamUrl}", ch.name)
                    4 -> {
                        prefs.lastChannelUrl = ch.streamUrl
                        prefs.lastChannelName = ch.name
                        prefs.bootMode = 2
                        Toast.makeText(this, "TV Boot DTH Mode ON: ${ch.name}", Toast.LENGTH_LONG).show()
                    }
                }
            }
            .show()
    }

    private fun showPlayerPickerForChannel(ch: LiveChannel) {
        val players = allInstalledApps.filter { it.isLiveTvCandidate }
            .ifEmpty { allInstalledApps }
        val names = (listOf("System Chooser (Ask every time)") + players.map { it.label }).toTypedArray()
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Play ${ch.name} using:")
            .setItems(names) { _, which ->
                if (which == 0) {
                    playLiveChannel(ch, "")
                } else {
                    playLiveChannel(ch, players[which - 1].packageName)
                }
            }
            .show()
    }

    private fun showPreferredPlayerDialog() {
        val players = allInstalledApps.filter { it.isLiveTvCandidate }.ifEmpty { allInstalledApps }
        val names = (listOf("Auto / System Chooser") + players.map { it.label }).toTypedArray()
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Default IPTV Stream Player")
            .setItems(names) { _, which ->
                if (which == 0) {
                    prefs.preferredIptvPlayer = ""
                    Toast.makeText(this, "Default player set to Auto", Toast.LENGTH_SHORT).show()
                } else {
                    val chosen = players[which - 1]
                    prefs.preferredIptvPlayer = chosen.packageName
                    Toast.makeText(this, "Default IPTV player: ${chosen.label}", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    // ==================== VOICE & UNIVERSAL SEARCH ====================
    private fun startVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak app or Live TV channel name...")
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_VOICE_SEARCH)
        } catch (_: Throwable) {
            Toast.makeText(this, "Opening keyboard search", Toast.LENGTH_SHORT).show()
            toggleSearch(true)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VOICE_SEARCH && resultCode == Activity.RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                toggleSearch(true)
                etSearch.setText(spoken)
                etSearch.setSelection(spoken.length)
                performSearch(spoken)
            }
        }
    }

    private fun toggleSearch(show: Boolean) {
        if (show) {
            searchBarContainer.visibility = View.VISIBLE
            viewForYou.visibility = View.GONE
            viewLive.visibility = View.GONE
            viewApps.visibility = View.GONE
            viewLibrary.visibility = View.GONE
            viewSearchResults.visibility = View.VISIBLE
            etSearch.setText("")
            etSearch.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(etSearch, InputMethodManager.SHOW_IMPLICIT)
            performSearch("")
        } else {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(etSearch.windowToken, 0)
            searchBarContainer.visibility = View.GONE
            viewSearchResults.visibility = View.GONE
            selectTab(currentTab)
        }
    }

    private fun performSearch(query: String) {
        val q = query.trim()
        val hidden = prefs.getHiddenPackages()
        val visibleApps = allInstalledApps.filter { it.packageName !in hidden }

        val matchedApps = if (q.isEmpty()) visibleApps else visibleApps.filter {
            it.label.contains(q, true) || it.packageName.contains(q, true)
        }
        val matchedChannels = if (q.isEmpty()) allLiveChannels.take(15) else allLiveChannels.filter {
            it.name.contains(q, true) || it.group.contains(q, true)
        }.take(40)

        if (matchedChannels.isEmpty()) {
            tvSearchChannelCount.visibility = View.GONE
            rvSearchChannels.visibility = View.GONE
        } else {
            tvSearchChannelCount.visibility = View.VISIBLE
            rvSearchChannels.visibility = View.VISIBLE
            tvSearchChannelCount.text = "Live TV Channels (${matchedChannels.size})"
            searchChannelsAdapter.submitList(matchedChannels)
        }

        tvSearchResultCount.text = if (q.isEmpty()) {
            "All Apps (${matchedApps.size})"
        } else {
            "Apps for \"$q\" (${matchedApps.size})"
        }
        searchAppsAdapter.submitList(matchedApps)
    }

    // ==================== APPS ENGINE ====================
    private fun loadAppsAsync() {
        bgExecutor.execute {
            val pm = packageManager
            val tvPackages = mutableSetOf<String>()
            val combinedMap = linkedMapOf<String, AppItem>()

            // 1. All Android TV / Leanback apps
            val tvIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            for (ri in pm.queryIntentActivities(tvIntent, 0)) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg == packageName) continue
                tvPackages.add(pkg)
                val label = ri.loadLabel(pm)?.toString()?.trim().orEmpty().ifEmpty { pkg }
                combinedMap[pkg] = AppItem(pkg, label, true, isLiveCandidate(pkg, label))
            }

            // 2. All Standard + Sideloaded apps
            val stdIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (ri in pm.queryIntentActivities(stdIntent, 0)) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg == packageName) continue
                if (!combinedMap.containsKey(pkg)) {
                    val label = ri.loadLabel(pm)?.toString()?.trim().orEmpty().ifEmpty { pkg }
                    combinedMap[pkg] = AppItem(pkg, label, pkg in tvPackages, isLiveCandidate(pkg, label))
                }
            }

            val sorted = combinedMap.values.sortedWith(
                compareByDescending<AppItem> { it.packageName == "com.harindra.iptvpro" }
                    .thenByDescending { it.isTvApp }
                    .thenBy { it.label.lowercase(Locale.getDefault()) }
            )

            mainHandler.post {
                allInstalledApps = sorted
                if (prefs.getPinnedPackages().isEmpty() && sorted.isNotEmpty()) {
                    prefs.savePinnedPackages(sorted.take(8).map { it.packageName })
                }
                featuredHeroApp = sorted.firstOrNull { it.packageName == "com.harindra.iptvpro" }
                    ?: sorted.firstOrNull { it.isLiveTvCandidate }
                    ?: sorted.firstOrNull()

                refreshUiLists()
                updateHeroBanner()
            }
        }
    }

    private fun isLiveCandidate(pkg: String, label: String): Boolean {
        val lower = (pkg + " " + label).lowercase(Locale.getDefault())
        return liveTvKeywords.any { lower.contains(it) }
    }

    private fun refreshUiLists() {
        val hidden = prefs.getHiddenPackages()
        val visible = allInstalledApps.filter { it.packageName !in hidden }
        val mapByPkg = visible.associateBy { it.packageName }

        val pinnedPkgs = prefs.getPinnedPackages()
        val pinnedList = pinnedPkgs.mapNotNull { mapByPkg[it] }.ifEmpty { visible.take(8) }
        pinnedAdapter.submitList(pinnedList)
        libraryFavAdapter.submitList(pinnedList)

        val recentList = prefs.getRecentPackages().mapNotNull { mapByPkg[it] }
        if (recentList.isEmpty()) {
            tvRecentHeader.visibility = View.GONE
            rvRecentApps.visibility = View.GONE
        } else {
            tvRecentHeader.visibility = View.VISIBLE
            rvRecentApps.visibility = View.VISIBLE
            recentAdapter.submitList(recentList)
        }

        allRowAdapter.submitList(visible)
        liveAppsAdapter.submitList(visible.filter { it.isLiveTvCandidate }.ifEmpty { visible.take(10) })
        refreshAppsGrid()
    }

    private fun refreshAppsGrid() {
        val hidden = prefs.getHiddenPackages()
        val visible = allInstalledApps.filter { it.packageName !in hidden }
        val filtered = when (currentAppFilter) {
            1 -> visible.filter { it.isTvApp }
            2 -> visible.filter { !it.isTvApp }
            else -> visible
        }
        tvAppsTitle.text = when (currentAppFilter) {
            1 -> "TV Apps (${filtered.size})"
            2 -> "Sideloaded Apps (${filtered.size})"
            else -> "All Apps (${filtered.size})"
        }
        allGridAdapter.submitList(filtered)
    }

    private fun launchAppWithLockCheck(item: AppItem) {
        if (item.packageName in prefs.getLockedPackages()) {
            promptKidsPin("Unlock ${item.label}") { launchAppDirect(item) }
        } else {
            launchAppDirect(item)
        }
    }

    private fun launchAppDirect(item: AppItem) {
        val intent = packageManager.getLeanbackLaunchIntentForPackage(item.packageName)
            ?: packageManager.getLaunchIntentForPackage(item.packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            prefs.recordRecentPackage(item.packageName)
            try {
                startActivity(intent)
            } catch (_: Throwable) {
                Toast.makeText(this, "Cannot open ${item.label}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "${item.label} has no launch screen", Toast.LENGTH_SHORT).show()
        }
    }

    private fun promptKidsPin(title: String, onSuccess: () -> Unit) {
        val input = EditText(this).apply {
            hint = "Enter 4-digit PIN (Default: 1234)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#9AA5B8"))
            setPadding(32, 24, 32, 24)
        }
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("Unlock") { _, _ ->
                if (input.text?.toString() == prefs.kidsPin) {
                    onSuccess()
                } else {
                    Toast.makeText(this, "Wrong PIN!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAppOptionsDialog(item: AppItem) {
        val pinned = prefs.getPinnedPackages()
        val isPinned = item.packageName in pinned
        val locked = prefs.getLockedPackages()
        val isLocked = item.packageName in locked

        val options = mutableListOf<String>()
        options.add("▶ Open ${item.label}")
        options.add(if (isPinned) "📌 Unpin from Your Apps" else "📌 Pin to Your Apps")
        if (isPinned) {
            options.add("⬅️ Move Left in Your Apps")
            options.add("➡️ Move Right in Your Apps")
        }
        options.add("🔢 Assign Remote Speed-Dial Key (1-9)")
        options.add("🚀 Set as TV Boot Auto-Launch App")
        options.add(if (isLocked) "🔓 Unlock App (Remove Kids PIN)" else "🔒 Lock App with Kids PIN")
        options.add("🙈 Hide App from Home")
        options.add("ℹ️ App Info (Clear Cache / Force Stop)")
        options.add("🗑️ Uninstall App")

        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle(item.label)
            .setItems(options.toTypedArray()) { _, which ->
                val choice = options[which]
                when {
                    choice.startsWith("▶") -> launchAppWithLockCheck(item)
                    choice.startsWith("📌 Unpin") -> {
                        pinned.remove(item.packageName)
                        prefs.savePinnedPackages(pinned)
                        refreshUiLists()
                    }
                    choice.startsWith("📌 Pin") -> {
                        pinned.add(0, item.packageName)
                        prefs.savePinnedPackages(pinned)
                        refreshUiLists()
                    }
                    choice.startsWith("⬅️") -> {
                        val i = pinned.indexOf(item.packageName)
                        if (i > 0) {
                            pinned.removeAt(i)
                            pinned.add(i - 1, item.packageName)
                            prefs.savePinnedPackages(pinned)
                            refreshUiLists()
                        }
                    }
                    choice.startsWith("➡️") -> {
                        val i = pinned.indexOf(item.packageName)
                        if (i in 0 until pinned.lastIndex) {
                            pinned.removeAt(i)
                            pinned.add(i + 1, item.packageName)
                            prefs.savePinnedPackages(pinned)
                            refreshUiLists()
                        }
                    }
                    choice.startsWith("🔢") -> showSpeedDialAssignDialog("app:${item.packageName}", item.label)
                    choice.startsWith("🚀") -> {
                        prefs.autoLaunchPackage = item.packageName
                        prefs.bootMode = 1
                        Toast.makeText(this, "TV Boot Auto-Launch set to ${item.label}!", Toast.LENGTH_LONG).show()
                    }
                    choice.startsWith("🔓") -> {
                        promptKidsPin("Remove Lock on ${item.label}") {
                            locked.remove(item.packageName)
                            prefs.saveLockedPackages(locked)
                            refreshUiLists()
                            Toast.makeText(this, "Unlocked ${item.label}", Toast.LENGTH_SHORT).show()
                        }
                    }
                    choice.startsWith("🔒") -> {
                        locked.add(item.packageName)
                        prefs.saveLockedPackages(locked)
                        refreshUiLists()
                        Toast.makeText(this, "Locked ${item.label} (PIN: ${prefs.kidsPin})", Toast.LENGTH_SHORT).show()
                    }
                    choice.startsWith("🙈") -> {
                        val hidden = prefs.getHiddenPackages()
                        hidden.add(item.packageName)
                        prefs.saveHiddenPackages(hidden)
                        refreshUiLists()
                    }
                    choice.startsWith("ℹ️") -> {
                        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.parse("package:${item.packageName}")
                        }
                        try { startActivity(i) } catch (_: Throwable) {}
                    }
                    choice.startsWith("🗑️") -> {
                        val i = Intent(Intent.ACTION_DELETE).apply {
                            data = Uri.parse("package:${item.packageName}")
                        }
                        try { startActivity(i) } catch (_: Throwable) {}
                    }
                }
            }
            .show()
    }

    private fun showSpeedDialAssignDialog(target: String, label: String) {
        val keys = (1..9).map { d ->
            val current = prefs.getSpeedDial(d)
            if (current.isBlank()) "Remote Key $d (Empty)" else "Remote Key $d (Replace)"
        }.toTypedArray()

        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Assign Remote Number Key for $label")
            .setItems(keys) { _, which ->
                val digit = which + 1
                prefs.setSpeedDial(digit, target)
                refreshUiLists()
                refreshChannelLists()
                Toast.makeText(this, "Press '$digit' on TV Remote to launch $label!", Toast.LENGTH_LONG).show()
            }
            .setNeutralButton("Clear Key") { _, _ ->
                for (d in 1..9) {
                    if (prefs.getSpeedDial(d) == target) prefs.setSpeedDial(d, "")
                }
                refreshUiLists()
                refreshChannelLists()
            }
            .show()
    }

    // ==================== CUSTOMIZER SETTINGS ====================
    private fun showLauncherSettingsDialog() {
        val themeName = themes[prefs.themeIndex.coerceIn(0, themes.lastIndex)].first
        val bootLabel = when (prefs.bootMode) {
            1 -> "Auto-Open App (${allInstalledApps.firstOrNull { it.packageName == prefs.autoLaunchPackage }?.label ?: "None"})"
            2 -> "DTH Auto-Play Last Channel"
            else -> "UltraTV Home Instant (<1s)"
        }

        val items = arrayOf(
            "🏠 Set UltraTV Pro as Default Launcher",
            "📡 Add / Edit Live TV M3U Playlist (${allLiveChannels.size} ch)",
            "🎬 Default IPTV Stream Player",
            "🎨 Theme / Wallpaper: $themeName",
            "🚀 TV Boot Startup Mode: $bootLabel",
            "⚡ Ultra-Lite 512MB Mode: ${if (prefs.isUltraLiteMode) "ON" else "OFF"}",
            "🛡️ Auto 512MB RAM Guard: ${if (prefs.isAutoRamGuard) "ON" else "OFF"}",
            "🖼️ Hero Banner: ${if (prefs.showHeroBanner) "Visible" else "Hidden"}",
            "⚡ Quick Actions Bar: ${if (prefs.showQuickBar) "Visible" else "Hidden"}",
            "📊 Top RAM Meter: ${if (prefs.showRamMeter) "Visible" else "Hidden"}",
            "🕒 Clock Format: ${if (prefs.is24HourClock) "24-Hour" else "12-Hour"}",
            "🔢 Grid Columns: ${prefs.gridColumns}",
            "🔐 Change Kids Lock PIN (Current: ${prefs.kidsPin})",
            "👁️ Manage Hidden Apps (${prefs.getHiddenPackages().size})",
            "⚙️ Open Android TV System Settings"
        )

        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("UltraTV Pro Customizer")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> promptSetDefaultLauncher()
                    1 -> showM3uSetupDialog()
                    2 -> showPreferredPlayerDialog()
                    3 -> showThemePicker()
                    4 -> showBootModeDialog()
                    5 -> {
                        prefs.isUltraLiteMode = !prefs.isUltraLiteMode
                        applyUserPreferences()
                        refreshChannelLists()
                    }
                    6 -> {
                        prefs.isAutoRamGuard = !prefs.isAutoRamGuard
                        Toast.makeText(this, "Auto RAM Guard: ${if (prefs.isAutoRamGuard) "ON" else "OFF"}", Toast.LENGTH_SHORT).show()
                    }
                    7 -> {
                        prefs.showHeroBanner = !prefs.showHeroBanner
                        applyUserPreferences()
                    }
                    8 -> {
                        prefs.showQuickBar = !prefs.showQuickBar
                        applyUserPreferences()
                    }
                    9 -> {
                        prefs.showRamMeter = !prefs.showRamMeter
                        applyUserPreferences()
                    }
                    10 -> {
                        prefs.is24HourClock = !prefs.is24HourClock
                        updateClockAndStatus()
                    }
                    11 -> {
                        prefs.gridColumns = when (prefs.gridColumns) {
                            5 -> 6
                            6 -> 7
                            else -> 5
                        }
                        applyUserPreferences()
                        Toast.makeText(this, "Grid set to ${prefs.gridColumns} columns", Toast.LENGTH_SHORT).show()
                    }
                    12 -> showChangePinDialog()
                    13 -> showUnhideAppsDialog()
                    14 -> openSystemAction(Settings.ACTION_SETTINGS)
                }
            }
            .show()
    }

    private fun showBootModeDialog() {
        val modes = arrayOf(
            "Instant UltraTV Pro Home (<1 sec)",
            "Auto-Launch Favorite App (Pick App)",
            "DTH Mode: Auto-Play Last Watched Live Channel"
        )
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Choose TV Startup Mode")
            .setSingleChoiceItems(modes, prefs.bootMode) { dialog, which ->
                dialog.dismiss()
                if (which == 1) {
                    showBootAutoLaunchPicker()
                } else {
                    prefs.bootMode = which
                    Toast.makeText(this, "Boot Mode updated!", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showBootAutoLaunchPicker() {
        if (allInstalledApps.isEmpty()) return
        val names = allInstalledApps.map { it.label }.toTypedArray()
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Select App to Auto-Start on TV Boot")
            .setItems(names) { _, which ->
                val chosen = allInstalledApps[which]
                prefs.autoLaunchPackage = chosen.packageName
                prefs.bootMode = 1
                Toast.makeText(this, "${chosen.label} set for TV Boot Auto-Start", Toast.LENGTH_LONG).show()
            }
            .show()
    }

    private fun showChangePinDialog() {
        val input = EditText(this).apply {
            hint = "New 4-digit PIN"
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#9AA5B8"))
            setPadding(32, 24, 32, 24)
        }
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Set Kids Lock PIN")
            .setView(input)
            .setPositiveButton("Save PIN") { _, _ ->
                val pin = input.text?.toString()?.trim().orEmpty()
                if (pin.length >= 4) {
                    prefs.kidsPin = pin.take(4)
                    Toast.makeText(this, "PIN updated to ${prefs.kidsPin}", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Enter at least 4 digits", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showThemePicker() {
        val names = themes.map { it.first }.toTypedArray()
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Choose Theme")
            .setSingleChoiceItems(names, prefs.themeIndex) { dialog, which ->
                prefs.themeIndex = which
                applyUserPreferences()
                dialog.dismiss()
            }
            .show()
    }

    private fun showUnhideAppsDialog() {
        val hidden = prefs.getHiddenPackages().toList()
        if (hidden.isEmpty()) {
            Toast.makeText(this, "No hidden apps", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = hidden.map { pkg ->
            allInstalledApps.firstOrNull { it.packageName == pkg }?.label ?: pkg
        }.toTypedArray()

        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Select app to Unhide")
            .setItems(labels) { _, which ->
                val set = prefs.getHiddenPackages()
                set.remove(hidden[which])
                prefs.saveHiddenPackages(set)
                refreshUiLists()
            }
            .setNeutralButton("Unhide All") { _, _ ->
                prefs.saveHiddenPackages(emptySet())
                refreshUiLists()
            }
            .show()
    }

    private fun applyUserPreferences() {
        val idx = prefs.themeIndex.coerceIn(0, themes.lastIndex)
        rootContainer.setBackgroundResource(themes[idx].second)
        heroCard.visibility = if (prefs.showHeroBanner && !prefs.isUltraLiteMode) View.VISIBLE else View.GONE
        quickActionsBar.visibility = if (prefs.showQuickBar) View.VISIBLE else View.GONE
        btnRamBoost.visibility = if (prefs.showRamMeter) View.VISIBLE else View.GONE

        val appCols = prefs.gridColumns.coerceIn(4, 7)
        val chCols = (appCols - 1).coerceIn(3, 5)
        (rvLiveChannelsGrid.layoutManager as? GridLayoutManager)?.spanCount = chCols
        (rvLibraryFavChannels.layoutManager as? GridLayoutManager)?.spanCount = chCols
        (rvSearchChannels.layoutManager as? GridLayoutManager)?.spanCount = chCols
        (rvLiveApps.layoutManager as? GridLayoutManager)?.spanCount = appCols
        (rvAllGrid.layoutManager as? GridLayoutManager)?.spanCount = appCols
        (rvLibraryFavorites.layoutManager as? GridLayoutManager)?.spanCount = appCols
        (rvSearchResults.layoutManager as? GridLayoutManager)?.spanCount = appCols
    }

    private fun selectTab(tabIndex: Int) {
        currentTab = tabIndex
        if (searchBarContainer.visibility == View.VISIBLE) toggleSearch(false)

        tabForYou.isSelected = tabIndex == 0
        tabLive.isSelected = tabIndex == 1
        tabApps.isSelected = tabIndex == 2
        tabLibrary.isSelected = tabIndex == 3

        viewForYou.visibility = if (tabIndex == 0) View.VISIBLE else View.GONE
        viewLive.visibility = if (tabIndex == 1) View.VISIBLE else View.GONE
        viewApps.visibility = if (tabIndex == 2) View.VISIBLE else View.GONE
        viewLibrary.visibility = if (tabIndex == 3) View.VISIBLE else View.GONE
        viewSearchResults.visibility = View.GONE

        if (tabIndex == 2) updateFilterSelection()
        if (tabIndex == 3) updateDeviceHealthCard()
    }

    private fun updateFilterSelection() {
        btnFilterAll.isSelected = currentAppFilter == 0
        btnFilterTv.isSelected = currentAppFilter == 1
        btnFilterSideload.isSelected = currentAppFilter == 2
    }

    private fun updateHeroBanner() {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greeting = when (hour) {
            in 5..11 -> "Good Morning"
            in 12..16 -> "Good Afternoon"
            in 17..21 -> "Good Evening"
            else -> "Good Night"
        }
        tvHeroStorage.text = getStorageSummary()

        when (heroSlideIndex) {
            0 -> {
                val lastChName = prefs.lastChannelName
                if (lastChName.isNotBlank() && allLiveChannels.any { it.streamUrl == prefs.lastChannelUrl }) {
                    tvHeroBadge.text = "🔴 CONTINUE WATCHING LIVE TV"
                    tvHeroTitle.text = "$greeting • $lastChName"
                    tvHeroSubtitle.text = "Press OK to resume $lastChName instantly, or browse ${allLiveChannels.size} Live TV channels below."
                    tvHeroCta.text = "▶ Watch $lastChName"
                    ivHeroIcon.setImageResource(R.drawable.ic_tv_live)
                } else {
                    val app = featuredHeroApp
                    tvHeroBadge.text = "ULTRATV PRO • ZERO-LAG 512MB ENGINE"
                    tvHeroTitle.text = if (app != null) "$greeting • ${app.label}" else "$greeting • UltraTV Pro"
                    tvHeroSubtitle.text = if (app != null) {
                        "Zero ads, instant boot & direct IPTV control. Press OK to launch ${app.label}."
                    } else {
                        "Clean Google TV Pro launcher built for maximum TV speed."
                    }
                    tvHeroCta.text = if (app != null) "▶ Open ${app.label}" else "▶ Live TV Hub"
                    if (app != null) IconCache.loadAppIcon(packageManager, app.packageName, ivHeroIcon)
                    else ivHeroIcon.setImageResource(R.drawable.ic_launcher_logo)
                }
            }
            1 -> {
                val ram = getRamInfo()
                tvHeroBadge.text = "512MB RAM TURBO OPTIMIZER"
                tvHeroTitle.text = "Free RAM: ${ram.first} MB / ${ram.second} MB"
                tvHeroSubtitle.text = "Press OK anytime to clear background apps and keep your TV super smooth."
                tvHeroCta.text = "⚡ Boost RAM Now"
                ivHeroIcon.setImageResource(R.drawable.ic_boost)
            }
            else -> {
                tvHeroBadge.text = "REMOTE SPEED-DIAL & DTH MODE"
                tvHeroTitle.text = "Keys 1–9 • Themes • M3U Live TV"
                tvHeroSubtitle.text = "Hold OK on any app or channel to pin, lock with PIN, or assign Remote keys 1 to 9."
                tvHeroCta.text = "⚙️ Open Customizer"
                ivHeroIcon.setImageResource(R.drawable.ic_settings)
            }
        }
    }

    private fun promptSetDefaultLauncher() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                    return
                }
            }
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (_: Throwable) {
            try {
                val selector = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_HOME)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(Intent.createChooser(selector, "Select UltraTV Pro -> Always"))
            } catch (_: Throwable) {
                AlertDialog.Builder(this, R.style.GtvDialogTheme)
                    .setTitle("Set Default Launcher")
                    .setMessage("Go to TV Settings > Apps > Default Apps > Home App > UltraTV Pro.\n\nIf your TV locks the stock launcher, disable the stock launcher once using ADB TV / AtvTools, then UltraTV Pro opens in <1 sec on every boot.")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    private fun boostRamNow() {
        val before = getRamInfo().first
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        for (app in allInstalledApps) {
            if (app.packageName != packageName) {
                try { am.killBackgroundProcesses(app.packageName) } catch (_: Throwable) { }
            }
        }
        IconCache.trimMemory()
        System.gc()
        mainHandler.postDelayed({
            val after = getRamInfo().first
            val freed = (after - before).coerceAtLeast(0)
            updateClockAndStatus()
            updateHeroBanner()
            Toast.makeText(this, "⚡ Turbo Boost Done! Free RAM: $after MB (+$freed MB)", Toast.LENGTH_SHORT).show()
        }, 400L)
    }

    private fun updateClockAndStatus() {
        val now = Date()
        val timeFmt = if (prefs.is24HourClock) "HH:mm" else "h:mm a"
        tvClock.text = SimpleDateFormat(timeFmt, Locale.getDefault()).format(now)
        tvDate.text = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(now)

        val ram = getRamInfo()
        tvRamStatus.text = "${ram.first}MB"
        if (!btnRamBoost.hasFocus()) {
            tvRamStatus.setTextColor(
                when {
                    ram.first < 90 -> Color.parseColor("#F28B82")
                    ram.first < 160 -> Color.parseColor("#FDD663")
                    else -> Color.parseColor("#81C995")
                }
            )
        }
        ivWifi.alpha = if (isNetworkConnected()) 1.0f else 0.35f
    }

    private fun updateDeviceHealthCard() {
        val ram = getRamInfo()
        val storage = getStorageSummary()
        val online = if (isNetworkConnected()) "Connected" else "Offline"

        val speedDialLines = (1..9).mapNotNull { d ->
            val t = prefs.getSpeedDial(d)
            if (t.isBlank()) null else {
                val label = if (t.startsWith("app:")) {
                    val pkg = t.removePrefix("app:")
                    allInstalledApps.firstOrNull { it.packageName == pkg }?.label ?: pkg
                } else {
                    val url = t.removePrefix("ch:")
                    allLiveChannels.firstOrNull { it.streamUrl == url }?.name ?: "Live Channel"
                }
                "#$d:$label"
            }
        }.joinToString("  •  ").ifBlank { "Hold OK on any app/channel to assign Keys 1-9" }

        tvDeviceHealth.text = buildString {
            appendLine("TV Model: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})")
            appendLine("Memory (RAM): ${ram.first} MB Free / ${ram.second} MB Total  |  Auto Guard: ${if (prefs.isAutoRamGuard) "ON" else "OFF"}")
            appendLine("Storage: $storage  |  Network: $online")
            appendLine("Apps: ${allInstalledApps.size} Total (${allInstalledApps.count { !it.isTvApp }} Sideloaded)  |  Live Channels: ${allLiveChannels.size}")
            append("Remote Speed-Dial (1-9): $speedDialLines")
        }
    }

    private fun getRamInfo(): Pair<Long, Long> {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return Pair(mi.availMem / (1024L * 1024L), mi.totalMem / (1024L * 1024L))
    }

    private fun getStorageSummary(): String {
        return try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val availGb = stat.availableBytes / (1024.0 * 1024.0 * 1024.0)
            val totalGb = stat.totalBytes / (1024.0 * 1024.0 * 1024.0)
            String.format(Locale.US, "%.1f GB / %.1f GB free", availGb, totalGb)
        } catch (_: Throwable) {
            "Storage Ready"
        }
    }

    private fun isNetworkConnected(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } else {
            @Suppress("DEPRECATION")
            cm.activeNetworkInfo?.isConnected == true
        }
    }

    private fun openSystemAction(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            searchBarContainer.visibility == View.VISIBLE -> toggleSearch(false)
            currentTab != 0 -> {
                selectTab(0)
                tabForYou.requestFocus()
            }
            else -> tabForYou.requestFocus()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Don't hijack number keys when typing in search box
        if (searchBarContainer.visibility != View.VISIBLE) {
            val digit = when (keyCode) {
                KeyEvent.KEYCODE_1, KeyEvent.KEYCODE_NUMPAD_1 -> 1
                KeyEvent.KEYCODE_2, KeyEvent.KEYCODE_NUMPAD_2 -> 2
                KeyEvent.KEYCODE_3, KeyEvent.KEYCODE_NUMPAD_3 -> 3
                KeyEvent.KEYCODE_4, KeyEvent.KEYCODE_NUMPAD_4 -> 4
                KeyEvent.KEYCODE_5, KeyEvent.KEYCODE_NUMPAD_5 -> 5
                KeyEvent.KEYCODE_6, KeyEvent.KEYCODE_NUMPAD_6 -> 6
                KeyEvent.KEYCODE_7, KeyEvent.KEYCODE_NUMPAD_7 -> 7
                KeyEvent.KEYCODE_8, KeyEvent.KEYCODE_NUMPAD_8 -> 8
                KeyEvent.KEYCODE_9, KeyEvent.KEYCODE_NUMPAD_9 -> 9
                else -> 0
            }
            if (digit in 1..9) {
                val target = prefs.getSpeedDial(digit)
                if (target.startsWith("app:")) {
                    val pkg = target.removePrefix("app:")
                    val app = allInstalledApps.firstOrNull { it.packageName == pkg }
                    if (app != null) {
                        launchAppWithLockCheck(app)
                        return true
                    }
                } else if (target.startsWith("ch:")) {
                    val url = target.removePrefix("ch:")
                    val ch = allLiveChannels.firstOrNull { it.streamUrl == url }
                    if (ch != null) {
                        playLiveChannel(ch, null)
                        return true
                    }
                }
            }
        }

        when (keyCode) {
            KeyEvent.KEYCODE_MENU -> {
                showLauncherSettingsDialog()
                return true
            }
            KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_TV -> {
                selectTab(1)
                return true
            }
            KeyEvent.KEYCODE_SEARCH -> {
                toggleSearch(true)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}
