package com.harindra.tvlauncher

import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object IconCache {
    // Strictly capped at 3.5 MB total for ultra-smooth 512MB RAM Smart TVs
    private const val MAX_CACHE_KB = 3584
    private const val TARGET_ICON_PX = 84

    private val cache = object : LruCache<String, Bitmap>(MAX_CACHE_KB) {
        override fun sizeOf(key: String, value: Bitmap): Int {
            return (value.byteCount / 1024).coerceAtLeast(1)
        }
    }

    private val appExecutor = Executors.newFixedThreadPool(2)
    private val netExecutor = Executors.newFixedThreadPool(2)
    private val mainHandler = Handler(Looper.getMainLooper())

    fun loadAppIcon(pm: PackageManager, packageName: String, target: ImageView) {
        val key = "pkg:$packageName"
        target.tag = key
        val cached = cache.get(key)
        if (cached != null && !cached.isRecycled) {
            target.setImageBitmap(cached)
            return
        }

        target.setImageResource(R.drawable.ic_tv_live)

        appExecutor.execute {
            val bmp = try {
                val drawable = pm.getApplicationBanner(packageName)
                    ?: pm.getApplicationIcon(packageName)
                drawableToScaledBitmap(drawable)
            } catch (_: Throwable) {
                null
            }

            if (bmp != null) {
                cache.put(key, bmp)
                mainHandler.post {
                    if (target.tag == key && !bmp.isRecycled) {
                        target.setImageBitmap(bmp)
                    }
                }
            }
        }
    }

    fun loadChannelLogo(url: String, target: ImageView) {
        if (url.isBlank() || (!url.startsWith("http://") && !url.startsWith("https://"))) {
            target.tag = null
            target.setImageResource(R.drawable.ic_tv_live)
            return
        }

        val key = "url:$url"
        target.tag = key
        val cached = cache.get(key)
        if (cached != null && !cached.isRecycled) {
            target.setImageBitmap(cached)
            return
        }

        target.setImageResource(R.drawable.ic_tv_live)

        netExecutor.execute {
            val bmp = try {
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 3500
                    readTimeout = 4500
                    instanceFollowRedirects = true
                }
                if (conn.responseCode in 200..299) {
                    val bytes = conn.inputStream.use { it.readBytes() }
                    conn.disconnect()
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                    var sample = 1
                    while (bounds.outHeight / sample > TARGET_ICON_PX * 2 ||
                        bounds.outWidth / sample > TARGET_ICON_PX * 2
                    ) {
                        sample *= 2
                    }
                    val opts = BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inPreferredConfig = Bitmap.Config.ARGB_8888
                    }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                } else {
                    conn.disconnect()
                    null
                }
            } catch (_: Throwable) {
                null
            }

            if (bmp != null) {
                cache.put(key, bmp)
                mainHandler.post {
                    if (target.tag == key && !bmp.isRecycled) {
                        target.setImageBitmap(bmp)
                    }
                }
            }
        }
    }

    fun trimMemory() {
        cache.evictAll()
    }

    private fun drawableToScaledBitmap(drawable: Drawable): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            val src = drawable.bitmap
            if (src.width <= TARGET_ICON_PX * 2 && src.height <= TARGET_ICON_PX) {
                return src
            }
            val aspect = src.width.toFloat() / src.height.coerceAtLeast(1).toFloat()
            val outH = TARGET_ICON_PX
            val outW = (outH * aspect).toInt().coerceIn(TARGET_ICON_PX, TARGET_ICON_PX * 2)
            return Bitmap.createScaledBitmap(src, outW, outH, true)
        }

        val w = drawable.intrinsicWidth.takeIf { it > 0 } ?: TARGET_ICON_PX
        val h = drawable.intrinsicHeight.takeIf { it > 0 } ?: TARGET_ICON_PX
        val aspect = w.toFloat() / h.coerceAtLeast(1).toFloat()
        val outH = TARGET_ICON_PX
        val outW = (outH * aspect).toInt().coerceIn(TARGET_ICON_PX, TARGET_ICON_PX * 2)

        val bitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }
}
